import asyncio
import logging
from loader import bot
from database import init_db

# Импортируем хендлеры, чтобы они зарегистрировались
import handlers.admin.main_panel
import handlers.admin.mod_admin
import handlers.auth
import handlers.bot_menu
import handlers.userbot

logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)

async def main():
    print("⏳ Инициализация БД...")
    await init_db()
    print("✅ БОТ ЗАПУЩЕН И ГОТОВ К РАБОТЕ!")
    await bot.run_until_disconnected()

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())