import os

# === ТВОИ ДАННЫЕ ===
BOT_API_ID =           # ID от my.telegram.org (управляющего бота)
BOT_API_HASH = ""   # HASH (управляющего бота)
BOT_TOKEN = "8153271966:AAEraO3RpPJbx5BXRVnmrEsvjM2X6euHZ88"     # Токен от BotFather
ADMIN_ID = 7063766212        # Твой ID (кому слать коды)

# === ПУТИ ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FOLDER = os.path.join(BASE_DIR, 'database')
SESSIONS_FOLDER = os.path.join(BASE_DIR, 'sessions')
DB_PATH = os.path.join(DB_FOLDER, 'super_userbot.db')

# Создаем папки, если нет
os.makedirs(DB_FOLDER, exist_ok=True)
os.makedirs(SESSIONS_FOLDER, exist_ok=True)