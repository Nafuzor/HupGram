import os
import json

# Базовые модули
AVAILABLE_MODULES = {
    "antivirus": {"name": "🛡 Антивирус", "desc": "Проверка ZIP/EXE на вирусы.", "cmd": ".scan [ответом]", "version": "1.0"},
    "pm_shield": {"name": "🛡 Защитник ЛС", "desc": "Удаляет спам и ссылки от незнакомцев.", "cmd": "(Автоматически)", "version": "1.0"},
    "view_once": {"name": "📸 Ловец Фото", "desc": "Сохраняет исчезающие фото в логи.", "cmd": "(Автоматически)", "version": "1.0"},
    "spammer": {"name": "🧨 Рейд", "desc": "Спамер сообщений и ядерный удар по чату.", "cmd": ".spam, .stop, .nuke", "version": "1.0"},
    "react": {"name": "🤡 Авто-унижение", "desc": "Спам реакциями на конкретного человека.", "cmd": ".react <эмодзи>", "version": "1.0"},
    "chat_killer": {"name": "💀 Убийца Чатов", "desc": "Банит всех участников группы.", "cmd": ".banall", "version": "1.0"},
    "clone": {"name": "🎭 Клонатор", "desc": "Ворует чужую личность (Ава, Имя, Био).", "cmd": ".clone @user, .revert", "version": "1.0"},
    "fake_quote": {"name": "💬 Фейк-Цитата", "desc": "Делает картинку-цитату от лица юзера.", "cmd": ".q @user <текст>", "version": "1.0"},
    "stealth": {"name": "👻 Скрытность", "desc": "Сообщения-бомбы (удаляются по таймеру).", "cmd": ".bomb <сек> <текст>", "version": "1.0"},
    "afk": {"name": "💤 Умный AFK", "desc": "Отвечает людям, когда ты спишь.", "cmd": ".afk <причина>, .unafk", "version": "1.0"},
    "wipe": {"name": "🧹 Тотальная зачистка", "desc": "Удаляет все твои сообщения в чате.", "cmd": ".wipe", "version": "1.0"},
    "parser": {"name": "👁 Парсер", "desc": "Сбор всех участников открытой группы в TXT.", "cmd": ".parse", "version": "1.0"},
    "mass_tag": {"name": "📢 Масс-Тег", "desc": "Уведомляет всех участников скрыто.", "cmd": ".all <текст>", "version": "1.0"},
    "translator": {"name": "🌐 Переводчик", "desc": "Переводит сообщения на нужный язык.", "cmd": ".tr ru [ответом]", "version": "1.0"},
    "downloader": {"name": "📥 Загрузчик Медиа", "desc": "Качает TikTok/Insta/YT Reels без водяных знаков.", "cmd": ".dl <ссылка>", "version": "1.0"},
    "relay": {"name": "🔄 Авто-Граббер", "desc": "Ворует посты из чужого канала в твой.", "cmd": ".relay <откуда> <куда>", "version": "1.0"}
}

# Динамическая загрузка кастомных модулей от админа
CUSTOM_MODS_FILE = os.path.join(os.path.dirname(__file__), "custom_modules.json")

def load_all_modules():
    mods = AVAILABLE_MODULES.copy()
    if os.path.exists(CUSTOM_MODS_FILE):
        try:
            with open(CUSTOM_MODS_FILE, "r", encoding="utf-8") as f:
                customs = json.load(f)
                mods.update(customs)
        except: pass
    return mods

AVAILABLE_MODULES = load_all_modules()