async def handle_masstag(event, client, txt):
    await event.edit("⏳ Собираю участников для скрытого тега...")
    try:
        if event.is_private:
            return await event.edit("❌ Эта команда работает только в группах!")
            
        args = txt.split(maxsplit=1)
        message_text = args[1] if len(args) > 1 else "Внимание!"
        
        users = await client.get_participants(event.chat_id)
        mentions = ""
        
        # Создаем невидимые ссылки на каждого юзера
        for user in users:
            if not user.bot:
                # Символ '⠀' - это невидимый пробел (Braille Pattern Blank)
                mentions += f"[⠀](tg://user?id={user.id})"
                
        # Отправляем сообщение + невидимые теги
        await event.delete()
        await client.send_message(event.chat_id, message_text + mentions)
    except Exception as e:
        await event.edit(f"❌ Ошибка: {e}")