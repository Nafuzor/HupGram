async def handle_shield(event, client):
    # Работает только в личных сообщениях
    if not event.is_private: return
    
    sender = await event.get_sender()
    if not sender or sender.bot or sender.is_self: return
    
    # Если юзера нет в контактах
    if not sender.contact and not sender.mutual_contact:
        text = (event.text or "").lower()
        
        # Если в тексте есть ссылки или стоп-слова
        if "t.me/" in text or "http" in text or "крипта" in text:
            try:
                # Удаляем спам
                await event.delete()
                # Кидаем предупреждение (или можно сразу в ЧС)
                await client.send_message(event.chat_id, "🛡 **PM Shield:** Сообщение от незнакомца заблокировано за подозрительную ссылку.")
            except: pass