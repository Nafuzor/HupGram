import os

async def handle_parse(event, client):
    await event.edit("⏳ Парсинг участников группы...")
    try:
        if event.is_private:
            await event.edit("❌ Эта команда работает только в группах!")
            return
            
        users = await client.get_participants(event.chat_id)
        filename = f"parsed_{event.chat_id}.txt"
        
        with open(filename, "w", encoding="utf-8") as f:
            f.write("ID | Юзернейм | Имя\n")
            f.write("-" * 30 + "\n")
            for u in users:
                uname = f"@{u.username}" if u.username else "Нет"
                fname = u.first_name or "Нет"
                f.write(f"{u.id} | {uname} | {fname}\n")
                
        await client.send_file(event.chat_id, filename, caption=f"✅ Собрано {len(users)} участников.")
        await event.delete()
        os.remove(filename)
    except Exception as e:
        await event.edit(f"❌ Ошибка парсинга (Возможно админы скрыли список): {e}")