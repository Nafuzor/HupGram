import aiohttp

async def handle_translate(event, args):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        return await event.edit("⚠️ Ответьте на текстовое сообщение командой `.tr <язык>` (например, `.tr ru`)")
    
    target_lang = args[1] if len(args) > 1 else 'ru'
    text_to_translate = reply.text
    await event.edit("⏳ Перевожу...")

    url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={target_lang}&dt=t&q={text_to_translate}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                data = await response.json()
                translated_text = "".join([part[0] for part in data[0]])
                await event.edit(f"🌐 **Перевод ({target_lang}):**\n\n`{translated_text}`")
    except Exception as e:
        await event.edit(f"❌ Ошибка перевода: {e}")