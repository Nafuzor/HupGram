# Хранилище статусов (в памяти)
AFK_STATE = {}

async def handle_afk_cmd(event, owner_id, cmd, txt):
    if cmd == '.afk':
        reason = txt.split(maxsplit=1)[1] if len(txt.split()) > 1 else "Сплю или занят"
        AFK_STATE[owner_id] = reason
        await event.edit(f"💤 **Умный AFK включен.**\nПричина: `{reason}`")
    elif cmd == '.unafk':
        if owner_id in AFK_STATE: del AFK_STATE[owner_id]
        await event.edit("☀️ **AFK выключен. Вы снова онлайн.**")

async def handle_incoming(event, client, owner_id):
    if owner_id not in AFK_STATE: return
    
    # Отвечаем, если написали в ЛС или тегнули в группе
    if event.is_private or event.mentioned:
        reason = AFK_STATE[owner_id]
        sender = await event.get_sender()
        if getattr(sender, 'bot', False): return
        
        try:
            await event.reply(f"💤 **Я сейчас AFK.**\nПричина: `{reason}`\n\n*(Отвечу, когда вернусь)*")
        except: pass