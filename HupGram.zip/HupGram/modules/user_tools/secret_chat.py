import base64

async def handle_crypto(event, args, txt):
    if event.text.startswith('.enc'):
        if len(args) < 2: return await event.edit("⚠️ Что шифровать? `.enc <текст>`")
        
        text_to_hide = txt.split(maxsplit=1)[1]
        # Кодируем текст в Base64 (выглядит как набор случайных букв и цифр)
        encoded = base64.b64encode(text_to_hide.encode('utf-8')).decode('utf-8')
        await event.edit(f"🔐 **Зашифрованное сообщение:**\n`{encoded}`\n\n*(Ответь командой .dec чтобы прочитать)*")
        
    elif event.text.startswith('.dec'):
        reply = await event.get_reply_message()
        if not reply or not reply.text: return await event.edit("⚠️ Ответь на зашифрованное сообщение!")
        
        try:
            # Пытаемся достать текст из блока кода `...` или берем весь текст
            crypt_text = reply.text.replace("🔐 **Зашифрованное сообщение:**\n`", "").replace("`\n\n*(Ответь командой .dec чтобы прочитать)*", "").strip()
            decoded = base64.b64decode(crypt_text).decode('utf-8')
            await event.edit(f"🔓 **Расшифровано:**\n\n`{decoded}`")
        except Exception:
            await event.edit("❌ Не удалось расшифровать. Неверный формат.")