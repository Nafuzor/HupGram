import zipfile
import io

# Опасные расширения (стиллеры, ратники, майнеры)
DANGER_EXT = ['.exe', '.bat', '.cmd', '.scr', '.vbs', '.js', '.ps1']

async def handle_scan(event, client):
    reply = await event.get_reply_message()
    
    if not reply or not reply.document:
        await event.edit("⚠️ Ответьте на файл или архив командой `.scan`")
        return

    await event.edit("⏳ **Сканирование файла...**")
    
    doc = reply.document
    filename = next((attr.file_name for attr in doc.attributes if hasattr(attr, 'file_name')), "Unknown")
    
    # 1. Проверка прямого расширения
    if any(filename.lower().endswith(ext) for ext in DANGER_EXT):
        await event.edit(f"🔴 **ОПАСНОСТЬ! ЗАРАЖЕНО!**\nФайл: `{filename}`\nТип: Исполняемый файл (Вирус)\n❌ **НЕ СКАЧИВАТЬ!**")
        return

    # 2. Проверка внутренностей архива (ZIP) в оперативной памяти (без сохранения на диск)
    if filename.lower().endswith('.zip'):
        try:
            # Скачиваем файл в оперативную память (до 10 МБ, чтобы не зависнуть)
            if doc.size > 10 * 1024 * 1024:
                await event.edit("⚠️ Архив слишком большой для быстрого сканирования (>10MB).")
                return
                
            file_bytes = await client.download_file(doc, bytes)
            with zipfile.ZipFile(io.BytesIO(file_bytes)) as z:
                archive_files = z.namelist()
                
                # Ищем вирусы внутри
                threats = [f for f in archive_files if any(f.lower().endswith(ext) for ext in DANGER_EXT)]
                
                if threats:
                    threat_list = "\n".join([f"- `{t}`" for t in threats[:5]])
                    await event.edit(f"🔴 **ОПАСНОСТЬ! В АРХИВЕ ВИРУСЫ!**\n📁 Имя: `{filename}`\n🦠 Скрытые угрозы:\n{threat_list}\n❌ **НЕ ОТКРЫВАТЬ!**")
                else:
                    await event.edit(f"✅ **БЕЗОПАСНО.**\n📁 Архив `{filename}` чист. Внутри нет исполняемых скриптов.")
        except Exception as e:
            await event.edit(f"⚠️ Ошибка сканирования архива: Возможно он под паролем.")
            
    else:
        await event.edit(f"✅ **БЕЗОПАСНО.**\nФайл `{filename}` не является исполняемым или архивом.")