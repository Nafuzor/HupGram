from telethon import events
from database import get_settings, get_msg_from_db_by_id
from loader import bot

ACTIVE_TRACKERS = []

async def handle_cmd(event, client, owner_id, cmd, args, txt):
    if cmd == '.editlog':
        if owner_id in ACTIVE_TRACKERS:
            return await event.edit("✅ Отслеживание редакций уже активировано и работает в фоне!")
            
        ACTIVE_TRACKERS.append(owner_id)
        await event.edit("✅ **Логгер редакций запущен!**\nТеперь измененные сообщения будут отправляться в вашу группу логов.")

        # Динамически вешаем слушатель на изменения сообщений
        @client.on(events.MessageEdited)
        async def edit_handler(e):
            cfg = await get_settings(owner_id)
            if not cfg['monitor']: return
            
            log_chat_id = cfg.get('log_chat_id')
            if not log_chat_id: return

            # Ищем оригинальное сообщение в нашей базе данных
            old_msg_data = await get_msg_from_db_by_id(owner_id, e.id)
            if not old_msg_data: return 
            
            old_text = old_msg_data[5]
            new_text = e.text or ""

            # Игнорируем, если текст не поменялся (например, изменилась клавиатура)
            if old_text == new_text: return 

            text = f"✏️ **ОТРЕДАКТИРОВАНО СООБЩЕНИЕ!**\n\n"
            text += f"👤 **От:** {old_msg_data[3]}\n"
            text += f"💬 **Чат:** {old_msg_data[4]}\n\n"
            text += f"❌ **БЫЛО:**\n`{old_text}`\n\n"
            text += f"✅ **СТАЛО:**\n`{new_text}`"

            try:
                await bot.send_message(log_chat_id, text)
            except Exception as err:
                print(f"EditTracker Error: {err}")