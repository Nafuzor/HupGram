import asyncio

async def handle_bomb(event, client, args, full_text):
    if len(args) < 3:
        await event.edit("⚠️ Использование: `.bomb <секунды> <текст>`")
        return
        
    try:
        timer = int(args[1])
        msg_text = full_text.split(maxsplit=2)[2]
        
        # Отправляем сообщение с пометкой
        sent = await event.edit(f"💣 {msg_text}")
        
        # Ждем таймер
        await asyncio.sleep(timer)
        
        # Удаляем для всех
        await sent.delete()
    except Exception as e:
        await event.edit(f"❌ Ошибка: {e}")