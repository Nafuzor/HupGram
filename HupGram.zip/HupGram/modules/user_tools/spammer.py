import asyncio
from telethon import functions

SPAM_FLAGS = {}

async def handle_spammer(event, client, owner_id, cmd, args, full_text):
    if cmd == '.spam' and len(args) >= 3:
        await event.delete()
        count = int(args[1])
        text_to_spam = full_text.split(maxsplit=2)[2]
        SPAM_FLAGS[owner_id] = True
        for _ in range(count):
            if not SPAM_FLAGS.get(owner_id, False): break
            await client.send_message(event.chat_id, text_to_spam)
            await asyncio.sleep(0.1)
            
    elif cmd == '.stop':
        await event.delete()
        SPAM_FLAGS[owner_id] = False
        
    elif cmd == '.nuke':
        await event.edit("☢️ ЯДЕРНЫЙ УДАР...")
        try:
            await client(functions.messages.DeleteHistoryRequest(peer=event.chat_id, max_id=0, revoke=True, just_clear=False))
        except Exception as e:
            await event.edit(f"❌ Ошибка Nuke: {e}")