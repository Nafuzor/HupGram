async def handle_viewonce(event, client, log_chat_id):
    if not event.media: return
    
    # Проверяем, есть ли у медиа таймер (ttl_seconds)
    if hasattr(event.media, 'ttl_seconds') and getattr(event.media, 'ttl_seconds', 0) > 0:
        try:
            # Скачиваем до того, как оно исчезнет
            file = await client.download_media(event.message)
            sender = await event.get_sender()
            sender_name = getattr(sender, 'first_name', 'Unknown')
            
            # Отправляем в группу логов
            if log_chat_id:
                caption = f"📸 **ПЕРЕХВАТ ИСЧЕЗАЮЩЕГО ФОТО**\n👤 От: {sender_name}"
                await client.send_file(log_chat_id, file, caption=caption)
            
            import os
            os.remove(file)
        except Exception as e:
            print(f"ViewOnce Error: {e}")