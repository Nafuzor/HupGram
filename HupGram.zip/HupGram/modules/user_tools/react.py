from telethon import functions, types

# {owner_id: {chat_id: {target_user_id: "emoji"}}}
REACT_STATE = {}

async def handle_react_cmd(event, owner_id, cmd, args):
    if cmd == '.react' and len(args) == 3:
        target = args[1].replace('@', '')
        emoji = args[2]
        
        if owner_id not in REACT_STATE: REACT_STATE[owner_id] = {}
        if event.chat_id not in REACT_STATE[owner_id]: REACT_STATE[owner_id][event.chat_id] = {}
        
        REACT_STATE[owner_id][event.chat_id][target] = emoji
        await event.edit(f"🤡 Авто-унижение включено!\nБуду ставить {emoji} на каждое сообщение пользователя {target}.")
        
    elif cmd == '.stopreact':
        if owner_id in REACT_STATE and event.chat_id in REACT_STATE[owner_id]:
            REACT_STATE[owner_id][event.chat_id].clear()
        await event.edit("✅ Авто-реакции в этом чате выключены.")

async def handle_incoming(event, client, owner_id):
    if owner_id not in REACT_STATE: return
    chat_state = REACT_STATE[owner_id].get(event.chat_id, {})
    if not chat_state: return

    sender = await event.get_sender()
    if not sender: return
    
    uname = sender.username or str(sender.id)
    
    # Ищем, есть ли этот юзер в нашем списке унижений
    emoji = chat_state.get(uname) or chat_state.get(str(sender.id))
    
    if emoji:
        try:
            # Моментально ставим реакцию
            await client(functions.messages.SendReactionRequest(
                peer=event.chat_id, msg_id=event.id,
                reaction=[types.ReactionEmoji(emoticon=emoji)]
            ))
        except: pass