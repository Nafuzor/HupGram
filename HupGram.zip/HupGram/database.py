import aiosqlite
import json
from config import DB_PATH

async def init_db():
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                owner_id INTEGER, chat_id INTEGER, message_id INTEGER,
                sender_name TEXT, chat_title TEXT, text_content TEXT,
                media_type TEXT, date TEXT, PRIMARY KEY (owner_id, chat_id, message_id)
            )
        ''')
        await db.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                owner_id INTEGER PRIMARY KEY, is_monitoring INTEGER DEFAULT 1, target_users TEXT DEFAULT '[]',
                auto_reply_on INTEGER DEFAULT 0, auto_reply_text TEXT DEFAULT 'Занят.',
                api_id INTEGER DEFAULT 0, api_hash TEXT DEFAULT '', mirror_media INTEGER DEFAULT 0, phone_number TEXT DEFAULT '',
                listen_777000 INTEGER DEFAULT 0, cloud_password TEXT DEFAULT '', log_chat_id INTEGER DEFAULT 0, 
                orig_fname TEXT DEFAULT '', orig_lname TEXT DEFAULT '', orig_bio TEXT DEFAULT ''
            )
        ''')
        # Обновление таблиц (в том числе новая колонка для пути к файлу)
        columns = [
            'installed_modules TEXT DEFAULT "[]"', 
            'active_modules TEXT DEFAULT "[]"',
            'log_other_id INTEGER DEFAULT 0',
            'file_path TEXT DEFAULT ""'
        ]
        for col in columns:
            try: await db.execute(f'ALTER TABLE settings ADD COLUMN {col}')
            except: pass
            
        # Добавляем file_path и в таблицу messages
        try: await db.execute('ALTER TABLE messages ADD COLUMN file_path TEXT DEFAULT ""')
        except: pass
        
        await db.commit()

async def get_settings(owner_id):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        async with db.execute('SELECT * FROM settings WHERE owner_id = ?', (owner_id,)) as c:
            row = await c.fetchone()
            if not row:
                await db.execute('INSERT INTO settings (owner_id) VALUES (?)', (owner_id,))
                await db.commit()
                return await get_settings(owner_id)
            return {
                'monitor': row[1], 'targets': json.loads(row[2]) if row[2].startswith('[') else [],
                'reply_on': row[3], 'reply_text': row[4], 'api_id': row[5], 'api_hash': row[6],
                'mirror': row[7], 'phone': row[8], 'listen_code': row[9], 'password': row[10],
                'log_chat_id': row[11], 'orig_fname': row[12], 'orig_lname': row[13], 'orig_bio': row[14],
                'installed': json.loads(row[15]) if len(row) > 15 and row[15] else [],
                'active': json.loads(row[16]) if len(row) > 16 and row[16] else [],
                'log_other_id': row[17] if len(row) > 17 else 0
            }

async def update_setting(owner_id, column, value):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute(f'UPDATE settings SET {column} = ? WHERE owner_id = ?', (value, owner_id))
        await db.commit()

async def get_user_modules(owner_id):
    cfg = await get_settings(owner_id)
    return cfg['installed'], cfg['active']

async def toggle_module(owner_id, module_name, is_install=True):
    cfg = await get_settings(owner_id)
    installed, active = cfg['installed'], cfg['active']
    if is_install:
        if module_name not in installed: installed.append(module_name)
        if module_name not in active: active.append(module_name)
    else:
        if module_name in active: active.remove(module_name)
        if module_name in installed: installed.remove(module_name)
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        await db.execute('UPDATE settings SET installed_modules = ?, active_modules = ? WHERE owner_id = ?', (json.dumps(installed), json.dumps(active), owner_id))
        await db.commit()

async def switch_module(owner_id, module_name):
    installed, active = await get_user_modules(owner_id)
    if module_name in installed:
        if module_name in active: active.remove(module_name)
        else: active.append(module_name)
        async with aiosqlite.connect(DB_PATH, timeout=10) as db:
            await db.execute('UPDATE settings SET active_modules = ? WHERE owner_id = ?', (json.dumps(active), owner_id))
            await db.commit()

async def save_msg_to_db(owner_id, event, file_path=""):
    try:
        s = await event.get_sender()
        name = getattr(s, 'first_name', 'Unknown') if s else 'Unknown'
        chat = await event.get_chat()
        chat_title = getattr(chat, 'title', 'Личные сообщения') if chat else 'Unknown'
        
        m_type = "Текст"
        if event.media:
            if hasattr(event.media, 'document'):
                if event.voice: m_type = "Голосовое (ГС)"
                elif event.video_note: m_type = "Кружок"
                elif event.sticker: m_type = "Стикер"
                elif event.video: m_type = "Видео"
                else: m_type = "Файл/Документ"
            elif hasattr(event.media, 'photo'): m_type = "Фото"
            else: m_type = "Медиа"

        async with aiosqlite.connect(DB_PATH, timeout=10) as db:
            # Используем REPLACE, чтобы перезаписывать данные
            await db.execute('INSERT OR REPLACE INTO messages VALUES (?,?,?,?,?,?,?,?,?)',
                             (owner_id, event.chat_id, event.id, name, chat_title, event.text or "", m_type, str(event.date), file_path))
            await db.commit()
    except Exception as e: 
        print(f"DB Save Error: {e}")

async def get_msg_from_db_by_id(owner_id, msg_id):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        async with db.execute('SELECT * FROM messages WHERE owner_id=? AND message_id=?', (owner_id, msg_id)) as c:
            return await c.fetchone()

async def get_last_messages(owner_id, limit=10):
    async with aiosqlite.connect(DB_PATH, timeout=10) as db:
        async with db.execute('SELECT sender_name, text_content, media_type, date FROM messages WHERE owner_id = ? ORDER BY message_id DESC LIMIT ?', (owner_id, limit)) as c:
            return await c.fetchall()