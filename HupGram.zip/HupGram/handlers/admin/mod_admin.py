import os
import re
import json
from telethon import events, Button
from config import ADMIN_ID
from loader import bot, auth_state
import modules.config_mods as cfg_mods

CUSTOM_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "modules", "custom_modules.json")
TOOLS_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "modules", "user_tools")

def get_customs():
    if os.path.exists(CUSTOM_PATH):
        with open(CUSTOM_PATH, "r", encoding="utf-8") as f:
            try: return json.load(f)
            except: return {}
    return {}

def save_customs(data):
    with open(CUSTOM_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

@bot.on(events.CallbackQuery(pattern=b'^mod_|^me_'))
async def mod_admin_cbs(event):
    if event.sender_id != ADMIN_ID: return
    d = event.data.decode()

    # --- ГЛАВНОЕ МЕНЮ И СПИСКИ ---
    if d == 'mod_menu':
        btn = [
            [Button.inline("➕ Добавить модуль", b'mod_add')],
            [Button.inline("📋 Существующие модули", b'mod_list')],
            [Button.inline("🔙 В админку", b'admin_home')]
        ]
        await event.edit("⚙️ **Управление модулями:**", buttons=btn)

    elif d == 'mod_list':
        all_mods = cfg_mods.load_all_modules()
        btn = []
        for m_id, m_data in all_mods.items():
            st = "🙈" if m_data.get('hidden') else "👁"
            btn.append([Button.inline(f"{st} {m_data['name']}", f"mod_e_{m_id}".encode())])
        btn.append([Button.inline("🔙 Назад", b'mod_menu')])
        await event.edit("📋 **Выберите модуль для управления:**", buttons=btn)

    # --- ПРОСМОТР МОДУЛЯ ---
    elif d.startswith('mod_e_'):
        m_id = d.split('_', 2)[2]
        all_mods = cfg_mods.load_all_modules()
        m_data = all_mods.get(m_id)
        if not m_data: return await event.answer("Модуль не найден!", alert=True)
        
        txt = (f"🛠 **Модуль:** {m_data['name']} (`{m_id}`)\n"
               f"⚙️ Версия: `{m_data['version']}`\n"
               f"📖 Описание: _{m_data['desc']}_\n"
               f"⌨️ Команды: `{m_data['cmd']}`")
               
        btn = [
            [Button.inline("✏️ Редактировать", f"mod_edit_{m_id}".encode())],
            [Button.inline("🙈 Скрыть" if not m_data.get('hidden') else "👁 Раскрыть", f"mod_h_{m_id}".encode())],
            [Button.inline("🗑 Удалить модуль", f"mod_d_{m_id}".encode())],
            [Button.inline("🔙 К списку", b'mod_list')]
        ]
        await event.edit(txt, buttons=btn)

    # --- СКРЫТЬ / УДАЛИТЬ ---
    elif d.startswith('mod_h_'):
        m_id = d.split('_', 2)[2]
        customs = get_customs()
        if m_id not in customs: # Если это базовый модуль, копируем его в кастомные для настройки
            customs[m_id] = cfg_mods.AVAILABLE_MODULES[m_id].copy()
            
        customs[m_id]['hidden'] = not customs[m_id].get('hidden', False)
        save_customs(customs)
        
        await event.answer("Статус видимости изменен!", alert=True)
        event.data = f"mod_e_{m_id}".encode()
        await mod_admin_cbs(event) 

    elif d.startswith('mod_d_'):
        m_id = d.split('_', 2)[2]
        customs = get_customs()
        if m_id in customs:
            del customs[m_id]
            save_customs(customs)
        # Удаляем файл кода
        f_path = os.path.join(TOOLS_PATH, f"{m_id}.py")
        if os.path.exists(f_path): os.remove(f_path)
        
        await event.answer("🗑 Модуль удален!", alert=True)
        event.data = b'mod_list'
        await mod_admin_cbs(event)

    # --- МЕНЮ РЕДАКТИРОВАНИЯ ---
    elif d.startswith('mod_edit_'):
        m_id = d.split('_', 2)[2]
        btn = [
            [Button.inline("🆔 Системный ID", f"me_id_{m_id}".encode()), Button.inline("📝 Название", f"me_name_{m_id}".encode())],
            [Button.inline("⚙️ Версия", f"me_ver_{m_id}".encode()), Button.inline("📖 Описание", f"me_desc_{m_id}".encode())],
            [Button.inline("⌨️ Команды", f"me_cmd_{m_id}".encode()), Button.inline("💻 Код (.py)", f"me_code_{m_id}".encode())],
            [Button.inline("🔙 Назад к модулю", f"mod_e_{m_id}".encode())]
        ]
        await event.edit(f"✏️ **Что именно вы хотите изменить в модуле `{m_id}`?**", buttons=btn)

    # --- ВЫБОР ПОЛЯ ДЛЯ РЕДАКТИРОВАНИЯ ---
    elif d.startswith('me_'):
        parts = d.split('_', 2)
        field = parts[1]
        m_id = parts[2]
        
        auth_state[event.chat_id] = {'step': f'edit_{field}', 'm_id': m_id}
        
        prompts = {
            'id': "Введите новый **Системный ID** (английские буквы и _):",
            'name': "Введите новое **Отображаемое Имя**:",
            'ver': "Введите новую **Версию**:",
            'desc': "Введите новое **Описание**:",
            'cmd': "Введите новые **Команды**:",
            'code': "Отправьте новый **КОД** текстом или прикрепите `.py` файл:"
        }
        await event.edit(f"✍️ {prompts[field]}\n\nДля отмены нажмите кнопку ниже.", buttons=[[Button.inline("🔙 Отмена", f"mod_edit_{m_id}".encode())]])

    # --- ДОБАВЛЕНИЕ НОВОГО ---
    elif d == 'mod_add':
        auth_state[event.chat_id] = {'step': 'mod_new_name'}
        await event.edit("✍️ Введите **Системное ID** модуля (только английские буквы и цифры, без пробелов, например: `auto_spam`):\n\nОтмена: /admin")


# --- ОБРАБОТКА ВВОДА ТЕКСТА ---
@bot.on(events.NewMessage)
async def admin_mod_inputs(event):
    cid = event.chat_id
    if cid != ADMIN_ID or cid not in auth_state: return
    
    st = auth_state[cid]
    step = st.get('step')
    if not step: return
    
    txt = event.text

    # === РЕДАКТИРОВАНИЕ СУЩЕСТВУЮЩИХ ===
    if step.startswith('edit_'):
        m_id = st['m_id']
        customs = get_customs()
        
        # Если редактируем базовый, копируем его в кастомные
        if m_id not in customs:
            customs[m_id] = cfg_mods.AVAILABLE_MODULES.get(m_id, {}).copy()

        try:
            if step == 'edit_id':
                new_id = re.sub(r'[^a-z0-9_]', '', txt.lower())
                if not new_id or new_id in cfg_mods.load_all_modules():
                    return await event.respond("❌ Ошибка! ID пустой или уже занят. Попробуйте другой:")
                
                # Переименовываем ключ в JSON
                customs[new_id] = customs.pop(m_id)
                # Переименовываем файл кода
                old_file = os.path.join(TOOLS_PATH, f"{m_id}.py")
                new_file = os.path.join(TOOLS_PATH, f"{new_id}.py")
                if os.path.exists(old_file): os.rename(old_file, new_file)
                m_id = new_id # Обновляем ID для вывода

            elif step == 'edit_name': customs[m_id]['name'] = txt
            elif step == 'edit_ver': customs[m_id]['version'] = txt
            elif step == 'edit_desc': customs[m_id]['desc'] = txt
            elif step == 'edit_cmd': customs[m_id]['cmd'] = txt
            elif step == 'edit_code':
                file_path = os.path.join(TOOLS_PATH, f"{m_id}.py")
                if event.document and event.document.attributes[0].file_name.endswith('.py'):
                    await event.client.download_media(event.document, file_path)
                else:
                    with open(file_path, "w", encoding="utf-8") as f: f.write(txt)

            save_customs(customs)
            del auth_state[cid]
            await event.respond(f"✅ Изменения в модуле `{m_id}` сохранены!", buttons=[Button.inline("🔙 Вернуться к модулю", f"mod_e_{m_id}".encode())])
        
        except Exception as e:
            await event.respond(f"❌ Ошибка сохранения: {e}")
            del auth_state[cid]
        return

    # === СОЗДАНИЕ НОВОГО (FSM) ===
    if step == 'mod_new_name':
        clean_id = re.sub(r'[^a-z0-9_]', '', txt.lower())
        if not clean_id: return await event.respond("❌ Некорректный ID. Напиши английскими буквами:")
        st['m_id'] = clean_id; st['step'] = 'mod_new_title'
        await event.respond(f"✅ ID: `{clean_id}`\n\nНапиши **Отображаемое Имя** (например: `🚀 Авто-Спам`):")

    elif step == 'mod_new_title':
        st['name'] = txt; st['step'] = 'mod_new_ver'
        await event.respond("Версия модуля (например: `1.0`):")

    elif step == 'mod_new_ver':
        st['ver'] = txt; st['step'] = 'mod_new_desc'
        await event.respond("Описание модуля:")

    elif step == 'mod_new_desc':
        st['desc'] = txt; st['step'] = 'mod_new_cmd'
        await event.respond("Команды (например: `.spam, .stop`):")

    elif step == 'mod_new_cmd':
        st['cmd'] = txt; st['step'] = 'mod_new_code'
        await event.respond("Отправь **КОД** текстом ИЛИ прикрепи **.py файл**:")

    elif step == 'mod_new_code':
        m_id = st['m_id']
        file_path = os.path.join(TOOLS_PATH, f"{m_id}.py")
        try:
            if event.document and event.document.attributes[0].file_name.endswith('.py'):
                await event.client.download_media(event.document, file_path)
            else:
                with open(file_path, "w", encoding="utf-8") as f: f.write(txt)

            customs = get_customs()
            customs[m_id] = {"name": st['name'], "version": st['ver'], "desc": st['desc'], "cmd": st['cmd'], "hidden": False}
            save_customs(customs)
                
            del auth_state[cid]
            await event.respond(f"✅ Модуль `{m_id}` успешно создан!", buttons=[Button.inline("📋 В меню модулей", b'mod_menu')])
        except Exception as e:
            await event.respond(f"❌ Критическая ошибка при сохранении: {e}")
            del auth_state[cid]