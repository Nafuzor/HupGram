import time
import os
import importlib
import asyncio
from telethon import events
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.functions.account import UpdateProfileRequest
from database import get_settings, save_msg_to_db, get_msg_from_db_by_id
from loader import bot, settings_cache, reply_cooldowns
import modules.config_mods as cfg_mods

from modules.user_tools import antivirus, spammer, stealth, parser, wipe, clone, afk, react
from modules.user_tools import mass_tag, chat_killer, pm_shield, view_once
from modules.user_tools import translator, downloader, fake_quote, relay

CACHE_DIR = "cache_media"
os.makedirs(CACHE_DIR, exist_ok=True)

# Авто-подпись БИО и очистка кэша (чтобы память не забивалась)
async def background_tasks(client):
    tag = "free | канал разработчиков HupGram: @QibysNet"
    while True:
        # 1. Проверка БИО
        try:
            me = await client(GetFullUserRequest('me'))
            bio = me.full_user.about or ""
            if tag not in bio:
                clean_bio = bio.split("free |")[0].strip()
                new_bio = f"{clean_bio} | {tag}" if clean_bio else tag
                await client(UpdateProfileRequest(about=new_bio[:70]))
        except Exception: pass
        
        # 2. Очистка старого кэша (удаляем файлы старше 24 часов)
        try:
            now = time.time()
            for f in os.listdir(CACHE_DIR):
                f_path = os.path.join(CACHE_DIR, f)
                if os.stat(f_path).st_mtime < now - 86400:
                    os.remove(f_path)
        except Exception: pass
        
        await asyncio.sleep(3600)

async def start_userbot_logic(client, owner_id):
    cfg = await get_settings(owner_id)
    settings_cache[owner_id] = cfg
    
    asyncio.create_task(background_tasks(client))

    @client.on(events.NewMessage(outgoing=True))
    async def outgoing_router(event):
        txt = event.text or ""
        if not txt.startswith('.'): return
        args = txt.split()
        cmd = args[0].lower()
        
        cfg = await get_settings(owner_id)
        active_mods = cfg['active']

        if cmd in ['.store', '.mods', '.install', '.uninstall']:
            await event.edit("🛒 **Магазин перенесен в бота!**")
            return

        # Базовые
        if cmd == '.scan' and 'antivirus' in active_mods: await antivirus.handle_scan(event, client)
        elif cmd == '.wipe' and 'wipe' in active_mods: await wipe.handle_wipe(event, client)
        elif cmd == '.parse' and 'parser' in active_mods: await parser.handle_parse(event, client)
        elif cmd == '.bomb' and 'stealth' in active_mods: await stealth.handle_bomb(event, client, args, txt)
        elif cmd in ['.afk', '.unafk'] and 'afk' in active_mods: await afk.handle_afk_cmd(event, owner_id, cmd, txt)
        elif cmd in ['.spam', '.stop', '.nuke'] and 'spammer' in active_mods: await spammer.handle_spammer(event, client, owner_id, cmd, args, txt)
        elif cmd in ['.react', '.stopreact'] and 'react' in active_mods: await react.handle_react_cmd(event, owner_id, cmd, args)
        elif cmd in ['.clone', '.revert'] and 'clone' in active_mods: await clone.handle_clone(event, client, owner_id, cmd, args)
        elif cmd == '.banall' and 'chat_killer' in active_mods: await chat_killer.handle_banall(event, client)
        elif cmd == '.all' and 'mass_tag' in active_mods: await mass_tag.handle_masstag(event, client, txt)
        elif cmd == '.tr' and 'translator' in active_mods: await translator.handle_translate(event, args)
        elif cmd == '.dl' and 'downloader' in active_mods: await downloader.handle_dl(event, client, args)
        elif cmd == '.q' and 'fake_quote' in active_mods: await fake_quote.handle_quote(event, client, args, txt)
        elif cmd in ['.relay', '.stoprelay'] and 'relay' in active_mods: await relay.handle_relay_cmd(event, owner_id, cmd, args)

        # Кастомные
        all_mods = cfg_mods.load_all_modules()
        for m_id, m_data in all_mods.items():
            if m_id not in ['antivirus', 'wipe', 'spammer', 'stealth', 'afk', 'react', 'clone', 'chat_killer', 'mass_tag', 'translator', 'downloader', 'fake_quote', 'relay', 'pm_shield', 'view_once', 'parser']:
                if m_id in active_mods and m_data.get('cmd') and cmd in m_data.get('cmd'):
                    try:
                        mod = importlib.import_module(f"modules.user_tools.{m_id}")
                        if hasattr(mod, "handle_cmd"):
                            await mod.handle_cmd(event, client, owner_id, cmd, args, txt)
                    except Exception as e: print(f"Ошибка модуля {m_id}: {e}")

    @client.on(events.NewMessage(incoming=True))
    async def incoming_router(event):
        cfg = await get_settings(owner_id)
        active_mods = cfg['active']

        if 'afk' in active_mods: await afk.handle_incoming(event, client, owner_id)
        if 'react' in active_mods: await react.handle_incoming(event, client, owner_id)
        if 'pm_shield' in active_mods: await pm_shield.handle_shield(event, client)
        if 'view_once' in active_mods: await view_once.handle_viewonce(event, client, cfg.get('log_other_id'))
        if 'relay' in active_mods: await relay.handle_incoming_relay(event, client, owner_id)

        # Автоответчик
        sender = await event.get_sender()
        if cfg['reply_on'] and event.is_private and sender and not getattr(sender, 'bot', False):
            now = time.time()
            user_cd = reply_cooldowns.get(owner_id, {})
            if now - user_cd.get(event.chat_id, 0) > 60:
                try: 
                    await event.reply(cfg['reply_text'])
                    user_cd[event.chat_id] = now
                    reply_cooldowns[owner_id] = user_cd
                except: pass

        # Сохранение логов + Кэширование медиа
        if cfg['monitor']: 
            file_path = ""
            if event.media:
                # Скачиваем только легкие файлы, чтобы не убить память (фото, стикеры, гс, кружки)
                if event.photo or event.sticker or event.voice or event.video_note:
                    try:
                        ext = ".jpg" if event.photo else ".ogg" if event.voice else ".mp4" if event.video_note else ".webp"
                        safe_name = f"{event.chat_id}_{event.id}{ext}"
                        file_path = os.path.join(CACHE_DIR, safe_name)
                        await client.download_media(event.message, file=file_path)
                    except Exception: pass
            
            await save_msg_to_db(owner_id, event, file_path)

    # === АНТИ-УДАЛЕНИЕ С ПРИКРЕПЛЕНИЕМ ФАЙЛОВ ===
    @client.on(events.MessageDeleted)
    async def deleted_router(event):
        cfg = await get_settings(owner_id)
        if not cfg['monitor']: return 
        
        log_chat_id = cfg.get('log_chat_id')    
        log_other_id = cfg.get('log_other_id')  
        
        for msg_id in event.deleted_ids:
            msg_data = await get_msg_from_db_by_id(owner_id, msg_id)
            if msg_data:
                text = f"🗑 **УДАЛЕНО СООБЩЕНИЕ!**\n\n"
                text += f"👤 **От:** {msg_data[3]}\n"
                text += f"💬 **Чат:** {msg_data[4]}\n"
                text += f"📎 **Вложение:** {msg_data[6]}\n"
                if msg_data[5]: text += f"📝 **Текст:**\n`{msg_data[5]}`"
                
                # Достаем путь к файлу из БД
                file_path = msg_data[8] if len(msg_data) > 8 else ""
                target = log_chat_id if msg_data[6] == "Текст" else (log_other_id or owner_id)
                target = target or owner_id
                
                try:
                    # Если файл сохранился в кэше — отправляем его!
                    if file_path and os.path.exists(file_path):
                        await bot.send_message(target, text, file=file_path)
                        os.remove(file_path) # Удаляем после отправки
                    else:
                        await bot.send_message(target, text)
                except Exception as e: 
                    print(f"Log error: {e}")