from telethon import TelegramClient
from config import BOT_API_ID, BOT_API_HASH, BOT_TOKEN

# Управляющий бот
bot = TelegramClient('bot_control', BOT_API_ID, BOT_API_HASH).start(bot_token=BOT_TOKEN)

# Хранилища данных
auth_state = {}       # Состояние входа (шаги)
settings_cache = {}   # Кэш настроек
active_clients = {}   # Запущенные юзерботы
reply_cooldowns = {}  # Таймеры автоответа