import os
import sys
import asyncio
from telethon import events, Button, errors
from config import SESSIONS_FOLDER
from loader import bot, active_clients, auth_state
from database import get_settings, update_setting, get_user_modules, switch_module, toggle_module
from handlers.userbot import start_userbot_logic
from handlers.auth import attempt_connect
import modules.config_mods as cfg_mods

async def safe_edit(event, text, buttons=None):
    try: 
        if hasattr(event, 'data'): await event.edit(text, buttons=buttons, link_preview=False)
        else: await event.respond(text, buttons=buttons, link_preview=False)
    except errors.MessageNotModifiedError: pass
    except Exception: pass

async def render_main_menu(event, cid):
    if cid not in active_clients:
        btn = [[Button.inline("🚀 Подключить Аккаунт", b'conn')]]
        await safe_edit(event, "👋 **Добро пожаловать в HupGram!**\nАвторизуйтесь для доступа к функциям.", btn)
        return

    btn = [
        [Button.inline("🛒 Магазин Модулей", b'm_store')],
        [Button.inline("📦 Мои Модули (Плагины)", b'm_mods')],
        [Button.inline("🤖 Автоответ", b'm_reply'), Button.inline("🕵️ Монитор", b'm_mon')],
        [Button.inline("🔄 Обновить", b'refresh'), Button.inline("♻️ Рестарт БОТА", b'restart')],
        [Button.inline("❌ Отключить сессию", b'disconn')]
    ]
    await safe_edit(event, f"🎛 **Панель управления HupGram**\nСтатус: 🟢 ПОДКЛЮЧЕН", btn)

async def render_store_menu(event, cid):
    installed, _ = await get_user_modules(cid)
    btn = []
    all_mods = cfg_mods.load_all_modules()
    
    for m_id, m_data in all_mods.items():
        if m_data.get('hidden'): continue
        if m_id not in installed:
            btn.append([Button.inline(f"➕ {m_data['name']}", f"s_{m_id}".encode())])
            
    if not btn: return await safe_edit(event, "🛒 **Магазин пуст!**\nВы установили всё.", [[Button.inline("🔙 Назад", b'refresh')]])
    btn.append([Button.inline("🔙 В главное меню", b'refresh')])
    await safe_edit(event, "🛒 **Магазин HupGram**\nВыберите модуль:", btn)

async def render_store_mod(event, cid, m_id):
    all_mods = cfg_mods.load_all_modules()
    m_data = all_mods.get(m_id)
    if not m_data: return
    text = (f"🛒 **Модуль:** {m_data['name']}\n⚙️ **Версия:** `{m_data['version']}`\n\n"
            f"📖 **Описание:**\n_{m_data['desc']}_\n\n⌨️ **Команда:** `{m_data['cmd']}`")
    btn = [[Button.inline("⬇️ УСТАНОВИТЬ", f"i_{m_id}".encode())], [Button.inline("🔙 Назад", b'm_store')]]
    await safe_edit(event, text, btn)

async def render_modules_menu(event, cid):
    installed, active = await get_user_modules(cid)
    all_mods = cfg_mods.load_all_modules()
    if not installed: return await safe_edit(event, "📦 **Ваши модули**\n\nПусто.", [[Button.inline("🔙 Назад", b'refresh')]])

    btn = []
    for m_id in installed:
        m_data = all_mods.get(m_id, {"name": m_id})
        if m_data.get('hidden'): continue
        st_icon = "🟢" if m_id in active else "🔴"
        btn.append([Button.inline(f"{st_icon} {m_data['name']}", f"m_{m_id}".encode())])
    btn.append([Button.inline("🔙 В главное меню", b'refresh')])
    await safe_edit(event, "📦 **Установленные модули**:", btn)

async def render_my_mod(event, cid, m_id):
    all_mods = cfg_mods.load_all_modules()
    m_data = all_mods.get(m_id, {"name": m_id, "desc": "Нет", "cmd": "Нет", "version": "1.0"})
    _, active = await get_user_modules(cid)
    is_on = m_id in active
    
    status = "🟢 ВКЛЮЧЕН" if is_on else "🔴 ВЫКЛЮЧЕН"
    btn = [
        [Button.inline(f"🔄 {'Выключить' if is_on else 'Включить'}", f"t_{m_id}".encode())],
        [Button.inline("🗑 УДАЛИТЬ", f"d_{m_id}".encode())],
        [Button.inline("🔙 К моим модулям", b'm_mods')]
    ]
    await safe_edit(event, f"📦 **{m_data['name']}**\n⚙️ Версия: `{m_data['version']}`\n📖 _{m_data['desc']}_\n⌨️ Команды: `{m_data['cmd']}`\n\nСтатус: {status}", btn)

@bot.on(events.NewMessage(pattern=r'(?i)^/start'))
async def start_handler(event):
    cid = event.chat_id
    if cid not in active_clients:
        s_path = os.path.join(SESSIONS_FOLDER, f"session_{cid}.session")
        if os.path.exists(s_path):
            cfg = await get_settings(cid)
            if cfg['api_id']:
                try: 
                    from telethon import TelegramClient
                    cl = TelegramClient(s_path.replace('.session',''), cfg['api_id'], cfg['api_hash'])
                    await cl.connect()
                    if await cl.is_user_authorized():
                        active_clients[cid] = cl
                        asyncio.create_task(start_userbot_logic(cl, cid))
                        await event.respond("⚡️ Авто-вход выполнен!")
                except Exception as e:
                    print(f"Auth error on start: {e}")
    await render_main_menu(event, cid)

@bot.on(events.CallbackQuery)
async def menu_callback(event):
    cid = event.chat_id
    d = event.data.decode()
    if d.startswith(('adm_', 'u_', 'l_', 'kill_', 'logs_', 'spam_', 'mod_')): return

    # --- Главное меню ---
    if d == 'refresh': await render_main_menu(event, cid)
    elif d == 'm_store': await render_store_menu(event, cid)
    elif d == 'm_mods': await render_modules_menu(event, cid)
    
    # --- Работа с модулями ---
    elif d.startswith('s_'): await render_store_mod(event, cid, d.split('_', 1)[1])
    elif d.startswith('i_'):
        await toggle_module(cid, d.split('_', 1)[1], is_install=True)
        await event.answer("✅ Установлено!", alert=True)
        await render_store_menu(event, cid)
    elif d.startswith('m_'): await render_my_mod(event, cid, d.split('_', 1)[1])
    elif d.startswith('t_'):
        m_id = d.split('_', 1)[1]
        await switch_module(cid, m_id)
        await render_my_mod(event, cid, m_id)
    elif d.startswith('d_'):
        await toggle_module(cid, d.split('_', 1)[1], is_install=False)
        await event.answer("🗑 Удалено!", alert=True)
        await render_modules_menu(event, cid)

    # --- Авторизация ---
    elif d == 'conn':
        cfg = await get_settings(cid)
        if cfg['api_id']:
            auth_state[cid] = {'step': 'check', 'api_id': cfg['api_id'], 'hash': cfg['api_hash']}
            await attempt_connect(cid, event)
        else:
            auth_state[cid] = {'step': 'api_id'}
            await safe_edit(event, "1️⃣ Введи **API ID**:", buttons=[Button.inline("🔙 Отмена", b'refresh')])
    elif d == 'disconn':
        if cid in active_clients:
            await active_clients[cid].disconnect()
            del active_clients[cid]
        await render_main_menu(event, cid)

    # --- Монитор (Анти-Удаление) ---
    elif d == 'm_mon':
        cfg = await get_settings(cid)
        st_mon = "✅ ВКЛ" if cfg['monitor'] else "❌ ВЫКЛ"
        await safe_edit(event, f"🕵️ **Мониторинг (Логгер)**\nСтатус: {st_mon}", [[Button.inline(f"Переключить Логгер", b't_mon')], [Button.inline("🔙 Назад", b'refresh')]])
    elif d == 't_mon':
        cfg = await get_settings(cid)
        await update_setting(cid, 'is_monitoring', 0 if cfg['monitor'] else 1)
        event.data = b'm_mon'  # Искусственно меняем данные и вызываем заново
        await menu_callback(event)

    # --- Автоответчик ---
    elif d == 'm_reply':
        cfg = await get_settings(cid)
        st = "✅ ВКЛ" if cfg['reply_on'] else "❌ ВЫКЛ"
        text = f"🤖 **Автоответчик**\nСтатус: {st}\n\nТекст:\n`{cfg['reply_text']}`"
        btn = [[Button.inline(f"Переключить: {st}", b't_reply')], [Button.inline("✏️ Изменить текст", b'edit_r')], [Button.inline("🔙 В меню", b'refresh')]]
        await safe_edit(event, text, btn)
    elif d == 't_reply':
        cfg = await get_settings(cid)
        await update_setting(cid, 'auto_reply_on', 0 if cfg['reply_on'] else 1)
        event.data = b'm_reply'
        await menu_callback(event)
    elif d == 'edit_r':
        auth_state[cid] = {'step': 'reply_text'}
        await safe_edit(event, "✍️ Новый текст:", buttons=[Button.inline("🔙 Отмена", b'm_reply')])

    # --- Системные ---
    elif d == 'restart':
        await event.answer("♻️ Перезагрузка...", alert=True)
        os.system(f'"{sys.executable}" ' + ' '.join(f'"{arg}"' for arg in sys.argv))
        sys.exit()