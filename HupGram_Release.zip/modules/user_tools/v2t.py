from telethon import events

async def handle_cmd(event, client, owner_id, cmd, args, txt):
    if cmd == '.v2t':
        reply = await event.get_reply_message()
        if not reply or not (reply.voice or reply.video_note):
            return await event.edit("⚠️ Ответьте на голосовое или кружок!")
            
        await event.edit("👂 **Слушаю...**")
        
        chat = "@VoiceMsgBot"
        
        try:
            # Сначала отправляем /start, чтобы открыть диалог (фиксит твою ошибку)
            async with client.conversation(chat) as conv:
                await conv.send_message("/start")
                await conv.get_response() # Ждем приветствие
                
                # Теперь кидаем голосовое
                fw = await reply.forward_to(chat)
                response = await conv.get_response()
                
                # Если бот ответил текстом
                if response.text:
                    await event.edit(f"🗣 **Расшифровка:**\n\n`{response.text}`")
                else:
                    await event.edit("❌ Не удалось распознать речь.")
                    
                # Удаляем мусор из чата с ботом
                await client.delete_messages(chat, [fw.id, response.id])
                
        except Exception as e:
            await event.edit(f"❌ Ошибка: {e}")