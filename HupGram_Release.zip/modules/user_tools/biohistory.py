# meta developer: @your_username
# scope: hikka_min 2.0.0
# meta name: Bio History
# meta description: Сохраняет историю изменений имен и юзернеймов всех, с кем вы общаетесь.

from .. import loader, utils
import time
from datetime import datetime

@loader.tds
class BioHistoryMod(loader.Module):
    """
    Модуль для отслеживания истории изменений профилей (Имя, Фамилия, Юзернейм).
    Работает в фоне, проверяя сообщения.
    """
    strings = {
        "name": "BioHistory",
        "no_history": "<b>❌ Истории изменений для этого пользователя нет.</b>",
        "history_header": "<b>👤 История изменений {user}:</b>\n\n",
        "loading": "🔄 <b>Поиск истории...</b>",
        "changed_fn": "📝 <b>Имя:</b> <code>{old}</code> ➡️ <code>{new}</code>",
        "changed_ln": "📝 <b>Фамилия:</b> <code>{old}</code> ➡️ <code>{new}</code>",
        "changed_un": "🔗 <b>Username:</b> <code>@{old}</code> ➡️ <code>@{new}</code>",
        "date_fmt": "📅 <b>{date}</b>:"
    }

    async def client_ready(self, client, db):
        self.client = client
        self.db = db

    def _get_full_name(self, user):
        """Вспомогательная функция для сборки полного имени"""
        fn = user.first_name if user.first_name else ""
        ln = user.last_name if user.last_name else ""
        return (fn + " " + ln).strip()

    @loader.watcher(out=True, only_messages=True)
    async def watcher(self, message):
        """Тихий наблюдатель, записывающий изменения"""
        if not message.sender or isinstance(message.sender, (type(None))):
            return

        # Игнорируем каналы и чаты, следим только за пользователями
        if not hasattr(message.sender, "id"):
            return
            
        user = message.sender
        uid = str(user.id)
        
        # Текущие данные
        current_data = {
            "fn": user.first_name,
            "ln": user.last_name,
            "un": user.username,
            "date": time.time()
        }

        # Получаем историю из базы
        history = self.db.get("BioHistory", "h_" + uid, [])

        if not history:
            # Если истории нет, сохраняем текущее состояние как начальное
            history.append(current_data)
            self.db.set("BioHistory", "h_" + uid, history)
            return

        # Берем последнюю запись
        last_entry = history[-1]

        # Проверяем, изменилось ли что-то (кроме времени)
        changed = False
        if (last_entry.get("fn") != current_data["fn"] or
            last_entry.get("ln") != current_data["ln"] or
            last_entry.get("un") != current_data["un"]):
            changed = True

        if changed:
            history.append(current_data)
            self.db.set("BioHistory", "h_" + uid, history)

    @loader.command
    async def history(self, message):
        """<@user или реплай> - Показать историю изменений профиля"""
        args = utils.get_args_raw(message)
        reply = await message.get_reply_message()
        
        message = await utils.answer(message, self.strings["loading"])

        user = None
        try:
            if reply:
                user = await self.client.get_entity(reply.sender_id)
            elif args:
                user = await self.client.get_entity(args)
            else:
                user = await self.client.get_entity(message.sender_id) # Если нет аргументов, чекаем себя или собеседника лс
        except:
            await utils.answer(message, "<b>❌ Не удалось найти пользователя.</b>")
            return

        uid = str(user.id)
        history = self.db.get("BioHistory", "h_" + uid, [])

        if len(history) < 2:
            await utils.answer(message, self.strings["no_history"])
            return

        text = self.strings["history_header"].format(user=self._get_full_name(user))
        
        # Проходим по истории и сравниваем i с i+1
        for i in range(len(history) - 1):
            old = history[i]
            new = history[i+1]
            
            # Форматируем дату изменения
            dt = datetime.fromtimestamp(new["date"]).strftime('%d.%m.%Y %H:%M')
            changes = []
            
            if old.get("fn") != new.get("fn"):
                changes.append(self.strings["changed_fn"].format(
                    old=old.get("fn") or "Empty", 
                    new=new.get("fn") or "Empty"
                ))
            
            if old.get("ln") != new.get("ln"):
                changes.append(self.strings["changed_ln"].format(
                    old=old.get("ln") or "Empty", 
                    new=new.get("ln") or "Empty"
                ))
                
            if old.get("un") != new.get("un"):
                changes.append(self.strings["changed_un"].format(
                    old=old.get("un") or "None", 
                    new=new.get("un") or "None"
                ))

            if changes:
                text += self.strings["date_fmt"].format(date=dt) + "\n"
                text += "\n".join(changes) + "\n\n"

        await utils.answer(message, text)