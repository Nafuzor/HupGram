import os
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
from database import update_setting, get_settings

async def handle_clone(event, client, owner_id, cmd, args):
    if cmd == '.clone' and len(args) == 2:
        await event.edit("🎭 Воруем личность...")
        try:
            target = await client(GetFullUserRequest(args[1]))
            me = await client(GetFullUserRequest('me'))
            
            # Сохраняем свое
            await update_setting(owner_id, 'orig_fname', me.users[0].first_name or "")
            await update_setting(owner_id, 'orig_lname', me.users[0].last_name or "")
            await update_setting(owner_id, 'orig_bio', me.full_user.about or "")
            
            # Меняем на чужое
            await client(UpdateProfileRequest(
                first_name=target.users[0].first_name or "",
                last_name=target.users[0].last_name or "",
                about=target.full_user.about or ""
            ))
            if target.full_user.profile_photo:
                pfp = await client.download_profile_photo(target.users[0])
                await client(UploadProfilePhotoRequest(await client.upload_file(pfp)))
                os.remove(pfp)
            await event.edit("✅ Личность успешно украдена!")
        except Exception as e:
            await event.edit(f"❌ Ошибка: {e}")

    elif cmd == '.revert':
        await event.edit("🔄 Возвращаем себя...")
        c = await get_settings(owner_id)
        await client(UpdateProfileRequest(first_name=c['orig_fname'], last_name=c['orig_lname'], about=c['orig_bio']))
        await client(DeletePhotosRequest(await client.get_profile_photos('me', limit=1)))
        await event.edit("✅ Своя личность возвращена!")