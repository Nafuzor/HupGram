import asyncio

async def handle_quote(event, client, args, txt):
    if len(args) < 3:
        return await event.edit("⚠️ Использование: `.q @username текст цитаты`")
        
    await event.edit("💬 Создаю цитату...")
    target_user = args[1]
    quote_text = txt.split(maxsplit=2)[2]
    
    try:
        # Отправляем сообщение специальному боту для цитат
        bot_username = "@QuotLyBot"
        # Эмулируем пересланное сообщение через бота
        msg = await client.send_message(bot_username, f"/qquote {target_user} {quote_text}")
        
        # Ждем ответ от бота (стикер)
        await asyncio.sleep(3)
        async for response in client.iter_messages(bot_username, limit=1):
            if response.sticker:
                # Пересылаем стикер в наш чат
                await client.send_message(event.chat_id, file=response.media)
                break
        
        # Удаляем следы
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ Ошибка генерации: {e}")