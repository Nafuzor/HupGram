# Память: {owner_id: {source_chat_id: dest_chat_id}}
RELAY_MAP = {}

async def handle_relay_cmd(event, owner_id, cmd, args):
    if cmd == '.relay':
        if len(args) < 3:
            return await event.edit("⚠️ Формат: `.relay <донор> <свой_канал>`\nНапример: `.relay @mudak @my_channel`")
        
        source = args[1]
        dest = args[2]
        
        if owner_id not in RELAY_MAP: RELAY_MAP[owner_id] = {}
        RELAY_MAP[owner_id][source] = dest
        
        await event.edit(f"✅ **Авто-Граббер запущен!**\nСлушаю: `{source}`\nКопирую в: `{dest}`")
        
    elif cmd == '.stoprelay':
        if owner_id in RELAY_MAP: RELAY_MAP[owner_id].clear()
        await event.edit("🛑 Авто-Граббер остановлен.")

async def handle_incoming_relay(event, client, owner_id):
    if owner_id not in RELAY_MAP: return
    
    # Получаем юзернейм канала, в котором вышел пост
    chat = await event.get_chat()
    chat_username = f"@{chat.username}" if getattr(chat, 'username', None) else str(chat.id)
    
    user_relays = RELAY_MAP[owner_id]
    
    # Если этот канал есть в списке доноров
    if chat_username in user_relays or str(chat.id) in user_relays:
        dest_chat = user_relays.get(chat_username) or user_relays.get(str(chat.id))
        try:
            # Копируем сообщение (не пересылаем, а именно создаем новое от лица юзера/бота)
            if event.media:
                await client.send_message(dest_chat, event.text, file=event.media)
            else:
                await client.send_message(dest_chat, event.text)
        except Exception as e:
            print(f"Relay Error: {e}")