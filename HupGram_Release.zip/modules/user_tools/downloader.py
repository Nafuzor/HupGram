import asyncio

async def handle_dl(event, client, args):
    if len(args) < 2:
        return await event.edit("⚠️ Укажите ссылку: `.dl <ссылка>`")
        
    link = args[1]
    await event.edit("📥 Скачиваю видео (без водяных знаков)...")
    
    try:
        bot_username = "@downloader_tiktok_bot" # Бесплатный бот-загрузчик
        # Отправляем ссылку боту
        await client.send_message(bot_username, link)
        
        # Ждем 5 секунд, пока бот скачает
        await asyncio.sleep(5)
        
        # Забираем последнее сообщение (видео) из чата с ботом
        video_found = False
        async for msg in client.iter_messages(bot_username, limit=3):
            if msg.media and (msg.video or msg.document):
                await client.send_file(event.chat_id, file=msg.media, caption="✅ Скачано через HupGram")
                video_found = True
                break
                
        if not video_found:
            await event.edit("❌ Не удалось скачать видео (возможно, неверная ссылка или бот перегружен).")
        else:
            await event.delete()
    except Exception as e:
        await event.edit(f"❌ Ошибка скачивания: {e}")