import asyncio

async def handle_wipe(event, client):
    await event.edit("🧹 Начинаю тотальную зачистку моих сообщений...")
    count = 0
    async for msg in client.iter_messages(event.chat_id, from_user='me'):
        try:
            await msg.delete()
            count += 1
        except: pass
    
    msg = await client.send_message(event.chat_id, f"✅ Успешно удалено {count} моих сообщений.")
    await asyncio.sleep(3)
    await msg.delete()