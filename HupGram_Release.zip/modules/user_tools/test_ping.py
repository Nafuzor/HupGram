import time

async def handle_cmd(event, client, owner_id, cmd, args, txt):
    if cmd == '.ping':
        start_time = time.time()
        msg = await event.edit("⏳ Замеряю пинг...")
        end_time = time.time()
        
        ping = round((end_time - start_time) * 1000, 2)
        await msg.edit(f"🏓 **PONG!**\n⚡️ Скорость отклика: `{ping} мс`\n✅ Кастомные модули работают отлично!")