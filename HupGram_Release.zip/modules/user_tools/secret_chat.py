import base64

async def handle_cmd(event, client, owner_id, cmd, args, txt):
    if cmd == '.enc':
        if len(args) < 2: 
            return await event.edit("⚠️ Пример: `.enc Привет`")
        
        # Берем текст после команды
        text_to_hide = txt.split(maxsplit=1)[1]
        
        # Шифруем в Base64
        encoded = base64.b64encode(text_to_hide.encode('utf-8')).decode('utf-8')
        
        # Отправляем ТОЛЬКО зашифрованную строку (в моноширинном блоке ` `)
        await event.edit(f"`{encoded}`")
        
    elif cmd == '.dec':
        reply = await event.get_reply_message()
        if not reply or not reply.text: 
            return await event.edit("⚠️ Ответь на зашифрованное сообщение!")
        
        try:
            # Убираем возможные символы форматирования (`), если юзер скопировал с ними
            clean_text = reply.text.replace("`", "").strip()
            
            # Расшифровываем
            decoded = base64.b64decode(clean_text).decode('utf-8')
            
            await event.edit(f"🔓 **Расшифровано:**\n\n`{decoded}`")
        except Exception:
            await event.edit("❌ Ошибка: Это не зашифрованный текст.")