import asyncio
from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.types import ChatBannedRights

async def handle_banall(event, client):
    await event.edit("🧨 **ЗАПУСК ПРОТОКОЛА УНИЧТОЖЕНИЯ ЧАТА...**")
    try:
        if event.is_private:
            return await event.edit("❌ Работает только в группах!")
            
        users = await client.get_participants(event.chat_id)
        # Права: Запретить вообще всё (БАН)
        ban_rights = ChatBannedRights(until_date=None, view_messages=True)
        
        banned_count = 0
        for user in users:
            # Не баним самих себя и создателя группы
            if user.is_self or user.id == event.sender_id: continue
            
            try:
                await client(EditBannedRequest(event.chat_id, user.id, ban_rights))
                banned_count += 1
                if banned_count % 10 == 0:
                    await event.edit(f"🧨 Уничтожение: Забанено {banned_count} чел...")
                await asyncio.sleep(0.1) # Задержка от флуда
            except: pass
            
        await event.edit(f"✅ **ЧАТ УНИЧТОЖЕН.**\nЗабанено: {banned_count} участников.")
    except Exception as e:
        await event.edit(f"❌ Ошибка (У вас нет прав админа?): {e}")